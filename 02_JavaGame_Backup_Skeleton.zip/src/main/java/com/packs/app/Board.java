package com.packs.app;

import javax.swing.JPanel;

public class Board extends JPanel {

    public Board() {}
}